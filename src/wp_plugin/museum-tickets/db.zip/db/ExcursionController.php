<?php


namespace MuseumTicketsPlugin\db;


class ExcursionController extends BaseController
{
    public function getAvalableDates($request) {
        $type_id = $request['type_id'];
        $sql = <<<SQL
SELECT distinct DATE(`when`) as date
FROM excursion WHERE type_id=? AND `when` > NOW() ORDER BY 1;
SQL;
        try {
            $statement = $this->db->prepare($sql);
            $result = $statement->execute([$type_id]);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            //exit($e->getMessage());
            //return $this->dbErrorResponse($e->getMessage());
            return \WP_REST_Response($e->getMessage(), 500);
        }

        return \WP_REST_Response($result, 200);
    }

}
